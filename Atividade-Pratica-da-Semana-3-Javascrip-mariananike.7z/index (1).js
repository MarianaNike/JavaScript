// Implementar comando de repetição (de 1 até 20)

// Implementar os comandos de decisão para verificar números quadrados pares ou ímpares

var par = 0;
var impar = 0;

for (var i = 1; i <= 20; i++) {
  var quad = i * i;
  console.log(quad);
 if (quad % 2 == 0) {
    par = par + quad;
  } else {
    impar = impar + quad;
  }
}

console.log ("A soma de quadrados Pares: ", par);
console.log("A soma de quadrados Impares: ", impar);
